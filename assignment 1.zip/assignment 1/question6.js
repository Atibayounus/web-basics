const express = require("express");

const app = express();

const PORT = 3000;

app.use(express.json());


app.post("/login", (req, res) => {
    const username = req.body.username;
    const password = req.body.password;

    console.log("Username:", username);
    console.log("Password:", password);

    res.send("Login details received");
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});