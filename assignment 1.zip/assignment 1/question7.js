const express = require("express");

const app = express();

const PORT = 3000;

app.get("/students", (req, res) => {
    const students = [
        {
            id: 1,
            name: "Ali"
        },
        {
            id: 2,
            name: "Ahmed"
        },
        {
            id: 3,
            name: "Atiba"
        }
    ];

    res.json(students);
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});