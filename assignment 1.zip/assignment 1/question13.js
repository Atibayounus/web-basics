const name = "Ali";
const country = "Pakistan";
let age = 20;


age = 21;

console.log("Name:", name);
console.log("Country:", country);
console.log("Age:", age);