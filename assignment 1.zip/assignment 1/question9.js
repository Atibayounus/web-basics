const express = require("express");

const app = express();

const PORT = 3000;

app.use(express.json());

// Todo array
let todos = [
    {
        id: 1,
        task: "Complete assignment"
    },
    {
        id: 2,
        task: "Learn Node.js"
    },
    {
        id: 3,
        task: "Practice Express"
    }
];

// DELETE route
app.delete("/todos/:id", (req, res) => {
    const id = parseInt(req.params.id);

    const todoIndex = todos.findIndex(todo => todo.id === id);

    if (todoIndex === -1) {
        return res.status(404).json({
            message: "Todo not found"
        });
    }

    todos.splice(todoIndex, 1);

    res.json({
        message: "Todo deleted successfully",
        todos: todos
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});