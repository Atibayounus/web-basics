const express = require('express');
const app = express();

app.use(express.json());

// Sample todos
const todos = [
  { id: 1, title: 'Learn Express', completed: false },
  { id: 2, title: 'Write Code', completed: true },
  { id: 3, title: 'Test API', completed: false }
];

//To GET /todos/:id
app.get('/todos/:id', (req, res) => {
  const id = parseInt(req.params.id);

  const todo = todos.find(todo => todo.id === id);

  if (!todo) {
    return res.status(404).json({ message: 'Todo not found' });
  }

  res.json(todo);
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});