const express = require('express');
const app = express();

app.use(express.json());

//a. Logger middleware
app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
});

//b. In-memory todos array
let todos = [
    { id: 1, title: "Learn Express", completed: false },
    { id: 2, title: "Build API", completed: true }
];

// c.GET /todos
app.get('/todos', (req, res) => {
    res.json(todos);
});

// POST /todos
app.post('/todos', (req, res) => {
    const newTodo = {
        id: todos.length + 1,
        title: req.body.title,
        completed: req.body.completed || false
    };

    todos.push(newTodo);
    res.status(201).json(newTodo);
});

// d.DELETE /todos/:id
app.delete('/todos/:id', (req, res) => {
    const id = parseInt(req.params.id);

    const index = todos.findIndex(todo => todo.id === id);

    if (index === -1) {
        return res.status(404).json({ message: "Todo not found" });
    }

    todos.splice(index, 1);
    res.json({ message: "Todo deleted successfully" });
});

//e. Start server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});