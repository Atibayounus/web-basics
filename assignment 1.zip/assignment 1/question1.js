// Program to print name, roll number, and department

console.log("Name: Atiba");
console.log("Roll Number: 25021519-095");
console.log("Department: Computer Science");

