const express = require('express');
const app = express();

// Middleware to parse JSON
app.use(express.json());

// Array to store users
const users = [];

// POST /users
app.post('/users', (req, res) => {
  const user = req.body;

  users.push(user);

  res.status(201).json({
    message: 'User added successfully',
    user: user
  });
});

// Now im Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});