let price = 100;
let quantity = 9;


let totalBill = price * quantity;


console.log("Price:", price);
console.log("Quantity:", quantity);
console.log("Total Bill:", totalBill);