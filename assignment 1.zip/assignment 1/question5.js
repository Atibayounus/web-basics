const express = require("express");

const app = express();

const PORT = 3000;

app.get("/about", (req, res) => {
    res.send("Atiba");
});

app.get("/contact", (req, res) => {
    res.send("25021519-095@uog.edu.pk");
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});