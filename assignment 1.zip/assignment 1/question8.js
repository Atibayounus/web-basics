const express = require("express");

const app = express();

const PORT = 3000;

// Logger middleware
const logger = (req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
};


app.use(logger);

// Routes
app.get("/", (req, res) => {
    res.send("Home Page");
});

app.get("/students", (req, res) => {
    res.json([
        { id: 1, name: "Ali" },
        { id: 2, name: "Ahmed" },
        { id: 3, name: "Atiba" }
    ]);
});


app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});